/*
* Ryan Reames
* CS-330-T3336
* 2/13/2023
*
* Final Project
* 
* Controls:
* W - forward
* S - backward
* A - left
* D - right
* Q - up
* E - down
* P - perspective / orthogonal views
* R - revolve light source
* Scroll up - increase movement speed
* Scroll down - decrease movement speed
* Mouse - move for camera angle changes
* Left click - reset view
* Escape - exit
* 
* *** EXCLUDE OBJ RESOURCE FILES FROM BUILD IN ORDER TO RUN PROGRAM *** (right click OBJ file - go to properties - exclude from build)
* 
* Code created with help of CS 330 tutorials and http://www.opengl-tutorial.org/
* Code for objloader and vboindexer taken from https://github.com/opengl-tutorials/ogl (code explained at opengl-tutorial.org)
* 
* Models were created in Blender and exported as an OBJ file. The objloader class loads in all related vertex coordinates,
* normals, and texture coordinates to arrays. Due to OBJ format, different indices are used for normals and texture coordinates.
* The vboindexer class takes all vertices / indices and creates a single indices array for all three by comparing values previously
* covered, and creating duplicate vertices if needed to match texture / normal coordinates. The two files allow
* OBJ files to be used in OpenGL along with their related texture, so long as obj files are triangulated (at least in this program).
* 
*
*/

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <vector>			// Used with objloader
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "objloader.hpp" // Get all vertex / index data from OBJ file
#include "vboindexer.hpp" // Create single indices array for vertices, normals, and textures

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace // Used in startUp function
{
	const char* const WINDOW_TITLE = "CS-330 Project Reames"; // Window title

	// Window size
	const int WINDOW_WIDTH = 1024;
	const int WINDOW_HEIGHT = 768;

	// Stores the GL data relative to a given mesh
	struct GLMesh
	{
		GLuint vao;         // Handle for the vertex array object
		GLuint vbo;         // Handle for the vertex buffer object
		GLuint nVertices;    // Number of indices of the mesh
	};

	// Main window
	GLFWwindow* window = nullptr;
	// Mesh with pyramid data
	GLMesh paintScene;
	const char* paintScenePath = "../OBJFiles/PaintingScene.obj";
	// Texture ID
	GLuint allPaintTextures;
	glm::vec2 gUVScale(1.0f, 1.0f);

	// Used for objloader and vboindexer
	std::vector<glm::vec3> vertices;
	std::vector<glm::vec2> uvs;
	std::vector<glm::vec3> normals;
	std::vector<unsigned short> indices;
	std::vector<glm::vec3> indexed_vertices;
	std::vector<glm::vec2> indexed_uvs;
	std::vector<glm::vec3> indexed_normals;
	GLuint vertexbuffer;
	GLuint uvbuffer;
	GLuint normalbuffer;
	GLuint elementbuffer;

	//Shader program
	GLuint programId;

	// camera settings
	glm::vec3 cameraPos = glm::vec3(-20.4f, 18.15f, -22.5f);
	glm::vec3 cameraFront = glm::vec3(0.61f, -0.78f, -0.13f);
	glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

	// Used for initial camera placement
	bool firstMouse = true;
	float yaw = -15.0f; // prevents from vector initially pointing wrong direction
	float pitch = -50.3f;
	float lastX = WINDOW_WIDTH / 2.0;
	float lastY = WINDOW_HEIGHT / 2.0;
	float fov = 45.0f;

	float cameraSpeed = 15.0f; // movement speed
	float sensitivity = 0.1f; // for camera angle speed

	// Used to change perspective based on keypress
	int viewCheck = 0;
	glm::mat4 projection = glm::perspective(glm::radians(fov), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 1000.0f);

	// timing
	float deltaTime = 0.0f;
	float lastFrame = 0.0f;

	// Cube and light color
	glm::vec3 gObjectColor(1.0f, 1.0f, 1.0f);
	glm::vec3 gLightColor(0.45f, 0.45f, 0.45f);
	glm::vec3 ambientColor(1.0f, 0.95f, 0.81f);

	// Light position
	glm::vec3 gLightPosition(13.0f, 45.0f, -40.6f);

	bool gIsLampOrbiting = false;

}

// Defined later, but starts up program, allows window resize, and renders graphics
bool startUp(int argc, char* argv[], GLFWwindow** window);
void onResize(GLFWwindow* window, int width, int height);
void checkInput(GLFWwindow* window);
//Creates mesh / destroys once used
void createMesh(GLMesh& mesh, const char* filePath);
void destroyMesh(GLMesh& mesh);
//Main render loop
void renderImage();
// Shader programs
bool createShader(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programID);
void destroyShader(GLuint programId);
void mousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
bool createTexture(const char* filename, GLuint& textureId);
void destroyTexture(GLuint textureId);

// Shaders for textured objects

/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,

layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec2 textureCoordinate;
layout(location = 2) in vec3 normal; // VAP position 1 for normals

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
	vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)
	vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
	vertexTextureCoordinate = textureCoordinate;
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
	in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;
out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;
uniform float ambientVal;
uniform vec3 ambientColor;

void main()
{
	/*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

	//Calculate Ambient lighting*/
	float ambientStrength = ambientVal; // Set ambient or global lighting strength
	vec3 ambient = ambientStrength * ambientColor; // Generate ambient light color

	//Calculate Diffuse lighting*/
	vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
	vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
	float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
	vec3 diffuse = impact * lightColor; // Generate diffuse light color

	//Calculate Specular lighting*/
	float specularIntensity = 1.5f; // Set specular light strength
	float highlightSize = 16.0f; // Set specular highlight size
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
	vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
	//Calculate specular component
	float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
	vec3 specular = specularIntensity * specularComponent * lightColor;

	// Texture holds the color to be used for all three components
	vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

	// Calculate phong result
	vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

	fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

// Main function required for program to execute
int main(int argc, char* argv[]) // Used for command line arguments
{

	if (!startUp(argc, argv, &window))
		return EXIT_FAILURE;

	createMesh(paintScene, paintScenePath); // creates VBO

	// Creates shader or exits if failure
	if (!createShader(vertexShaderSource, fragmentShaderSource, programId))
		return EXIT_FAILURE;
	
	// Load textures
	const char* texFilename = "../Textures/AllPaintObjects.jpg";
	if (!createTexture(texFilename, allPaintTextures))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	glUseProgram(programId);
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(programId, "uTexture"), 0);

	glClearColor(0.65f, 0.91f, 0.92f, 1.0f); // Sets initial window color to bright blue
		
	// This is the program loop that keeps the window open / rendering
	while (!glfwWindowShouldClose(window))
	{
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		checkInput(window); // Checks for user input
		renderImage(); // renders the image
		glfwPollEvents(); // checks for events from user
	}

	destroyMesh(paintScene);
	destroyShader(programId);
	destroyTexture(allPaintTextures);

	exit(EXIT_SUCCESS);
}

// Initializing the window
bool startUp(int argc, char* argv[], GLFWwindow** window)
{
	// Initializes GLFW
	glfwInit();
	// Determines OpenGL version to use
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Creates the window using namespace values
	*window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);

	// Checks if window was successfully created
	if (window == NULL)
	{
		std::cout << "GLFW window not created" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, onResize);
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); // prevents cursor from leaving screen
	glfwSetCursorPosCallback(*window, mousePositionCallback); // used for camera angle
	glfwSetScrollCallback(*window, mouseScrollCallback); // used for increasing / decreasing speed
	glfwSetMouseButtonCallback(*window, mouseButtonCallback); // used to reset position

	// Initialize GLEW
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	return true;
}

// Used on window refresh
void checkInput(GLFWwindow* window)
{
	// If escape is pressed, send notification that window should close
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraOffset = cameraSpeed * deltaTime;
	// movement controls
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += cameraOffset * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= cameraOffset * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraOffset;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraOffset;
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		cameraPos += cameraOffset * cameraUp;
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		cameraPos -= cameraOffset * cameraUp;
	// The following switches between perspective and orthographic views when the key P is pressed
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
	{
		if (viewCheck == 1)
		{
			viewCheck = 0;
			// Projection matrix - perspective
			projection = glm::perspective(glm::radians(fov), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 1000.0f);
		}
		else if (viewCheck == 0)
		{
			viewCheck = 1;
			projection = glm::ortho(-WINDOW_WIDTH / 100.0f, WINDOW_WIDTH / 100.0f, -WINDOW_HEIGHT / 100.0f, WINDOW_HEIGHT / 100.0f, -0.1f, 1000.0f);
		}
	}
	if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
	{
		if (gIsLampOrbiting == true)
			gIsLampOrbiting = false;
		else if (gIsLampOrbiting == false)
			gIsLampOrbiting = true;
	}
}

void mousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	// tracks mouse position
	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	// changes angle based on sensitivity
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// doesn't allow screen to flip
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}

void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	// increase speed by scrolling up, decrease by scrolling down
	cameraSpeed += (float)yoffset;
	if (cameraSpeed < 1.0f)
		cameraSpeed = 1.0f;
	if (cameraSpeed > 50.0f)
		cameraSpeed = 50.0f;
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
		// Reset view
	case GLFW_MOUSE_BUTTON_LEFT:
	{	
		yaw = -15.0f; // prevents from vector initially pointing to right
		pitch = -50.3f;
		cameraSpeed = 15.0f;
		cameraPos = glm::vec3(-20.4f, 18.15f, -22.5f);
		cameraFront = glm::vec3(0.61f, -0.78f, -0.13f);
		cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
		break;
	}

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		break;
	}

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		break;
	}
	}
}

// Used for resizing the window
void onResize(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

void renderImage()
{	
	// Lamp orbits around the origin (used for light positioning)
	const float angularVelocity = glm::radians(45.0f);
	if (gIsLampOrbiting)
	{
		glm::vec4 newPosition = glm::rotate(angularVelocity * deltaTime, glm::vec3(0.0f, 1.0f, 0.0f)) * glm::vec4(gLightPosition, 1.0f);
		gLightPosition.x = newPosition.x;
		gLightPosition.y = newPosition.y;
		gLightPosition.z = newPosition.z;

		std::cout << gLightPosition.x << " x " << gLightPosition.y << " y " << gLightPosition.z << " z" << endl;
	}
	glEnable(GL_DEPTH_TEST);

	glClearColor(0.65f, 0.91f, 0.92f, 1.0f); // Sets window color to bright blue
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/*---Green Paint Tube------------------------------------------------------------------------*/
	// Activate the cube VAO (used by cube and lamp)
	glBindVertexArray(paintScene.vao);

	// Set the shader to be used
	glUseProgram(programId);

	// Normal size
	glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));

	// Rotate shape 114 degrees x axis, 34 degrees y axis, -31 degrees z axis (based on radians)
	glm::mat4 rotation1 = glm::rotate(1.0f, glm::vec3(0.0f, -0.8f, 0.0f));

	// Origin
	glm::mat4 translation1 = glm::translate(glm::vec3(0.0f, 0.0f, -25.0f));

	// Apply left to right
	glm::mat4 model1 = translation1 * rotation1 * scale;

	// View matrix - translate camera
	glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

	// Transformations are applied right-to-left order
	//glm::mat4 transformation = translation * rotation * scale;
	glm::mat4 transformation(1.0f);

	// Selects shader program
	glUseProgram(programId);

	GLint modelLoc = glGetUniformLocation(programId, "model");
	GLint viewLoc = glGetUniformLocation(programId, "view");
	GLint projLoc = glGetUniformLocation(programId, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model1));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
	GLint objectColorLoc = glGetUniformLocation(programId, "objectColor");
	GLint lightColorLoc = glGetUniformLocation(programId, "lightColor");
	GLint lightPositionLoc = glGetUniformLocation(programId, "lightPos");
	GLint viewPositionLoc = glGetUniformLocation(programId, "viewPosition");
	float ambientStrength = glGetUniformLocation(programId, "ambientVal");
	GLint ambientColorLoc = glGetUniformLocation(programId, "ambientColor");

	// Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
	glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
	glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
	glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
	glUniform3f(viewPositionLoc, cameraPos.x, cameraPos.y, cameraPos.z);
	glUniform1f(ambientStrength, 0.6f);
	glUniform3f(ambientColorLoc, ambientColor.r, ambientColor.g, ambientColor.b);

	GLint UVScaleLoc = glGetUniformLocation(programId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, allPaintTextures);

	// 1rst attribute buffer : vertices
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glVertexAttribPointer(
		0,                  // attribute
		3,                  // size
		GL_FLOAT,           // type
		GL_FALSE,           // normalized?
		0,                  // stride
		(void*)0            // array buffer offset
	);

	// 2nd attribute buffer : UVs
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer);
	glVertexAttribPointer(
		1,                                // attribute
		2,                                // size
		GL_FLOAT,                         // type
		GL_FALSE,                         // normalized?
		0,                                // stride
		(void*)0                          // array buffer offset
	);

	// 3rd attribute buffer : normals
	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, normalbuffer);
	glVertexAttribPointer(
		2,                                // attribute
		3,                                // size
		GL_FLOAT,                         // type
		GL_FALSE,                         // normalized?
		0,                                // stride
		(void*)0                          // array buffer offset
	);

	// Index buffer
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementbuffer);
	// Draw the triangles !
	glDrawElements(
		GL_TRIANGLES,      // mode
		indices.size(),    // count
		GL_UNSIGNED_SHORT,   // type
		(void*)0           // element array buffer offset
	);

	// Deactivate the Vertex Array Object and shader program
	glBindVertexArray(0);

	glUseProgram(0);
	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(2);

	// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
	glfwSwapBuffers(window);    // Flips the the back buffer with the front buffer every frame.
}

void createMesh(GLMesh& mesh, const char* filePath)
{

	bool res = loadOBJ(filePath, vertices, uvs, normals);
	indexVBO(vertices, uvs, normals, indices, indexed_vertices, indexed_uvs, indexed_normals);

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 4 buffers: vertex data, uv data, normals, indices
	glGenBuffers(1, &vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, indexed_vertices.size() * sizeof(glm::vec3), &indexed_vertices[0], GL_STATIC_DRAW);

	glGenBuffers(1, &uvbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer);
	glBufferData(GL_ARRAY_BUFFER, indexed_uvs.size() * sizeof(glm::vec2), &indexed_uvs[0], GL_STATIC_DRAW);

	glGenBuffers(1, &normalbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, normalbuffer);
	glBufferData(GL_ARRAY_BUFFER, indexed_normals.size() * sizeof(glm::vec3), &indexed_normals[0], GL_STATIC_DRAW);

	// Generate a buffer for the indices as well
	glGenBuffers(1, &elementbuffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementbuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned short), &indices[0], GL_STATIC_DRAW);
}

void destroyMesh(GLMesh& mesh)
{
	glDeleteVertexArrays(1, &mesh.vao);
	glDeleteBuffers(1, &mesh.vbo);
}

/*Generate and load the texture*/
bool createTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}

void destroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}

bool createShader(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programID)
{
	// Used in error checking during compilation and linking
	int success = 0;
	char infoLog[512];

	programID = glCreateProgram(); // sets up object to add to

	// These also set up objects to be added to
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Provides the GLSL code to add to the shaders
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);

	glShaderSource(fragmentShaderId, 1, &fragmentShaderSource, NULL);

	// Compiles the code just provided
	glCompileShader(vertexShaderId);
	// Check for errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "Error - vertex shader compilation failed\n" << infoLog << std::endl;
		return false;
	}
	// Compile
	glCompileShader(fragmentShaderId);
	// Check for errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "Error - fragment shader compilation failed\n" << infoLog << std::endl;
		return false;
	}

	// Adds the compiled code to the created program
	glAttachShader(programID, vertexShaderId);
	glAttachShader(programID, fragmentShaderId);

	// Links the created shaders together within the program
	glLinkProgram(programID);
	// Check for errors
	glGetProgramiv(programID, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programID, sizeof(infoLog), NULL, infoLog);
		std::cout << "Error - shader linking failed\n" << infoLog << std::endl;
		return false;
	}

	return true;
}

void destroyShader(GLuint programId)
{
	glDeleteProgram(programId);
}